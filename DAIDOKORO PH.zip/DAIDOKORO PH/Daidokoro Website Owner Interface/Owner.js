function openAddSubForm() {
    document.getElementById("addbtn").style.display = "none";
    document.getElementById("delbtn").style.display = "none";
    document.getElementById("clrbtn").style.display = "none";
    document.getElementById("formaddsub").style.display = "block";

}

function closeAddSubForm() {
    document.getElementById("addbtn").style.display = "block";
    document.getElementById("delbtn").style.display = "block";
    document.getElementById("clrbtn").style.display = "block";
    document.getElementById("formaddsub").style.display = "none";
}

function openDelSubForm() {
    document.getElementById("addbtn").style.display = "none";
    document.getElementById("delbtn").style.display = "none";
    document.getElementById("clrbtn").style.display = "none";
    document.getElementById("formdelsub").style.display = "block";

}

function closeDelSubForm() {
    document.getElementById("addbtn").style.display = "block";
    document.getElementById("delbtn").style.display = "block";
    document.getElementById("clrbtn").style.display = "block";
    document.getElementById("formdelsub").style.display = "none";
}

function refreshPage() {
    window.location.reload();
}